import matplotlib.pyplot as plt
import numpy as np


mins = np.array([8223.155737704918,5494.836065573771,4145.737704918032,3337.4590163934427,2792.8688524590166,2409.4262295081967])
maxes = np.array([8492.540983606557,5821.88524590164,4433.196721311475,3518.1967213114754,2961.5573770491806,2559.1803278688526])
means = np.array([8318.07456840479,5604.420183770906,4235.533678624464,3414.245371606958,2860.306376286695,2464.1320720275107])
std = np.array([38.82999881803969,34.37939639617549,37.32854978770295,29.355751902814866,26.720407268691538,23.5850038172456])
# create stacked errorbars:
figure, axis = plt.subplots(6,1)
for graph in range(6):
    axis[graph].errorbar(graph+2, means[graph], std[graph], fmt='.k', lw=2, label="standard dev")
    axis[graph].errorbar(graph+2, means[graph], [[(means - mins)[graph]], [(maxes - means)[graph]]],fmt='.k', ecolor='gray', lw=1, label="max-min")
    axis[graph].set_xlim(1,8)
    axis[graph].set_ylim(means[graph]+250,means[graph]-250)
    axis[graph].spines['bottom'].set_visible(False)
    axis[graph].spines['top'].set_visible(False)
    axis[graph].xaxis.set_visible(False)

    d = .015  # how big to make the diagonal lines in axes coordinates
    kwargs = dict(transform=axis[graph].transAxes, color='k', clip_on=False)
    if(graph!=5):
        # arguments to pass to plot, just so we don't keep repeating them
        axis[graph].plot((-d, +d), (-d, +d), **kwargs)        # top-left diagonal
        axis[graph].plot((1 - d, 1 + d), (-d, +d), **kwargs)  # top-right diagonal

    if(graph!=0):
        kwargs.update(transform=axis[graph].transAxes)  # switch to the bottom axes
        axis[graph].plot((-d, +d), (1 - d, 1 + d), **kwargs)  # bottom-left diagonal
        axis[graph].plot((1 - d, 1 + d), (1 - d, 1 + d), **kwargs)  # bottom-right diagonal

axis[0].spines['top'].set_visible(True)
axis[5].spines['bottom'].set_visible(True)
axis[5].xaxis.set_visible(True)
axis[0].legend()
axis[0].set_title("Map 1")
figure.text(0.5, 0.04, 'Bot Count', ha='center', va='center')
figure.text(0.06, 0.5, 'Time in s', ha='center', va='center', rotation='vertical')
# plt.ylabel("log2(time)")
# plt.xlabel("Bot count")
# plt.legend()
plt.show()

plt.errorbar(np.arange(2,8), means, std, fmt='.k', lw=2, label="standard dev")
plt.errorbar(np.arange(2,8), means, [(means - mins), (maxes - means)],fmt='.k', ecolor='gray', lw=1, label="max-min")
plt.title("Map 4")
plt.xlabel("Bot count")
plt.ylabel("Time in s")
plt.legend()
plt.show()