"""
Purpose : 1) Remove all NA lines
		  2) Find time taken by each bot in each sim
		  3) Find max time for that sim
		  4) Find efficiency for that sim
		  5) Output all detials in file with format "in_pos -- max_time -- efficiency"
		  6) Remove path with efficiency <90%, among remaining find least time
"""
import numpy as np

input_file = open("4_map1.txt","r")
output_file = open("4_map1_final.txt","w")
content = input_file.read()
map_wise = content.split("\n")

# Bot count#
bot_count = 4

#Velocities and time parameter#
v_straight = 0.305
t_turns = 2.5

#Cleaning Efficiency#
straight_eff = 0.9066
turn_eff = 0.9078

#Lists to store time and corresponding position and mode#
time_list = []
position_list = []
efficiency_list = []

#Function to get time from straights and turns#
#Currently randomly defined, to be changed as per requirement#
def get_time(straights,turns,v_straight,time_per_unit_turn):
	time_per_unit_straight = 0.5/v_straight
	total_time = [int(straight)*time_per_unit_straight+int(turn)*time_per_unit_turn for straight,turn in zip(straights,turns)]
	#print(total_time)
	return max(total_time)

def get_efficiency(straights,turns,straight_eff,turn_eff):
	total_straights = sum([int(straight) for straight in straights])
	total_turns = sum([int(turn) for turn in turns])

	# sum_efficieny = [int(straight)*straight_eff+int(turn)*turn_eff for straight,turn in zip(straights,turns)]
	# sum_str_turn = [int(straight)+int(turn) for straight,turn in zip(straights,turns)]
	# total_efficiency = [efficiency/total for efficiency,total in zip(sum_efficieny,sum_str_turn)]

	total_efficiency = (total_straights*straight_eff + total_turns*turn_eff) / (total_straights+total_turns)
	return total_efficiency

def make_list_string(lst):
	return [str(item) for item in lst]

for line in map_wise:
	#Ignoring NA#
	if line == "NA" or line == "":
		continue
	else:
		#output_file.write(line+"\n")
		line_split = line.split(",")

		#Getting individual information from the line#
		positions = line_split[:bot_count]
		mode = line_split[bot_count]
		straights = line_split[bot_count+1:2*bot_count+1]
		turns = line_split[2*bot_count+1:]
		
		#Get time and store relevant information#
		time = get_time(straights,turns,v_straight,t_turns)

		efficiency = get_efficiency(straights,turns,straight_eff,turn_eff)

		output_file.write(','.join(positions)+','+mode+','+str(time)+','+str(efficiency)+'\n')

		time_list.append(time)
		position_list.append([positions,mode])
		efficiency_list.append(efficiency)
		

#Sort time array and correspondingly sort the position array#
time_list, position_list = zip(*sorted(zip(time_list, position_list)))
print("T_min: ",end=" ")
print(time_list[0])
print("T_min_in_pos: ",end=" ")
print(position_list[0])
print("T_mean: ",end=" ")
print(np.mean(time_list))
print("T_std: ",end=" ")
print(np.std(time_list))
print("T_max :",end=" ")
print(time_list[-1])
print("Efficiency_mean: ",end=" ")
print(100*np.mean(efficiency_list))
print("Efficiency_std: ",end=" ")
print(100*np.std(efficiency_list))

		
