import matplotlib.pyplot as plt
import numpy as np


mins = np.array([8282.786885245901,5535.983606557377,4194.75409836065,3369.9180327868853,2815.655737704918,2435.655737704918])
maxes = np.array([8568.196721311477,5857.868852459016,4434.877049180328,3567.0081967213114,2980.5737704918033,2568.1967213114754])
means = np.array([8392.330110717852,5663.914384883703,4273.442083692838,3440.9607503152583,2880.3048455325475,2478.6672744044376])
std = np.array([40.80246595890444,35.221980873365,33.38143553688552,29.818877153774096,26.683007866217704,22.665247837795786])
# create stacked errorbars:
figure, axis = plt.subplots(6,1)
for graph in range(6):
    axis[graph].errorbar(graph+2, means[graph], std[graph], fmt='.k', lw=2, label="standard dev")
    axis[graph].errorbar(graph+2, means[graph], [[(means - mins)[graph]], [(maxes - means)[graph]]],fmt='.k', ecolor='gray', lw=1, label="max-min")
    axis[graph].set_xlim(1,8)
    axis[graph].set_ylim(means[graph]+250,means[graph]-250)
    axis[graph].spines['bottom'].set_visible(False)
    axis[graph].spines['top'].set_visible(False)
    axis[graph].xaxis.set_visible(False)

    d = .015  # how big to make the diagonal lines in axes coordinates
    kwargs = dict(transform=axis[graph].transAxes, color='k', clip_on=False)
    if(graph!=5):
        # arguments to pass to plot, just so we don't keep repeating them
        axis[graph].plot((-d, +d), (-d, +d), **kwargs)        # top-left diagonal
        axis[graph].plot((1 - d, 1 + d), (-d, +d), **kwargs)  # top-right diagonal

    if(graph!=0):
        kwargs.update(transform=axis[graph].transAxes)  # switch to the bottom axes
        axis[graph].plot((-d, +d), (1 - d, 1 + d), **kwargs)  # bottom-left diagonal
        axis[graph].plot((1 - d, 1 + d), (1 - d, 1 + d), **kwargs)  # bottom-right diagonal

axis[0].spines['top'].set_visible(True)
axis[5].spines['bottom'].set_visible(True)
axis[5].xaxis.set_visible(True)
axis[0].legend()
axis[0].set_title("Map 1")
figure.text(0.5, 0.04, 'Bot Count', ha='center', va='center')
figure.text(0.06, 0.5, 'Time in s', ha='center', va='center', rotation='vertical')
# plt.ylabel("log2(time)")
# plt.xlabel("Bot count")
# plt.legend()
plt.show()

plt.errorbar(np.arange(2,8), means, std, fmt='.k', lw=2, label="standard dev")
plt.errorbar(np.arange(2,8), means, [(means - mins), (maxes - means)],fmt='.k', ecolor='gray', lw=1, label="max-min")
plt.title("Map 1")
plt.xlabel("Bot count")
plt.ylabel("Time in s")
plt.legend()
plt.show()