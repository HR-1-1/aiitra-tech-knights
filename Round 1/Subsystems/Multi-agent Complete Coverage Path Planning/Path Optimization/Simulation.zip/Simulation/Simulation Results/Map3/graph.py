import matplotlib.pyplot as plt
import numpy as np

mins = np.array([4298.196721311475,2872.7459016393445,2154.4262295081967,1729.7950819672133])
maxes = np.array([4408.0327868852455,3041.967213114754,2303.8524590163934,1877.295081967213])
means = np.array([4342.440406337922,2921.0242099449283,2210.9177857874706,1770.1546875580832])
std = np.array([14.65884728553315,38.29729620885859,26.885475193969903,25.96475631445388])
# create stacked errorbars:
figure, axis = plt.subplots(4,1)
for graph in range(4):
    axis[graph].errorbar(graph+2, means[graph], std[graph], fmt='.k', lw=2, label="standard dev")
    axis[graph].errorbar(graph+2, means[graph], [[(means - mins)[graph]], [(maxes - means)[graph]]],fmt='.k', ecolor='gray', lw=1, label="max-min")
    axis[graph].set_xlim(1,6)
    axis[graph].set_ylim(means[graph]+250,means[graph]-250)
    axis[graph].spines['bottom'].set_visible(False)
    axis[graph].spines['top'].set_visible(False)
    axis[graph].xaxis.set_visible(False)

    d = .015  # how big to make the diagonal lines in axes coordinates
    kwargs = dict(transform=axis[graph].transAxes, color='k', clip_on=False)
    if(graph!=3):
        # arguments to pass to plot, just so we don't keep repeating them
        axis[graph].plot((-d, +d), (-d, +d), **kwargs)        # top-left diagonal
        axis[graph].plot((1 - d, 1 + d), (-d, +d), **kwargs)  # top-right diagonal

    if(graph!=0):
        kwargs.update(transform=axis[graph].transAxes)  # switch to the bottom axes
        axis[graph].plot((-d, +d), (1 - d, 1 + d), **kwargs)  # bottom-left diagonal
        axis[graph].plot((1 - d, 1 + d), (1 - d, 1 + d), **kwargs)  # bottom-right diagonal

axis[0].spines['top'].set_visible(True)
axis[3].spines['bottom'].set_visible(True)
axis[3].xaxis.set_visible(True)
axis[0].legend()
axis[0].set_title("Map 3")
figure.text(0.5, 0.04, 'Bot Count', ha='center', va='center')
figure.text(0.06, 0.5, 'Time in s', ha='center', va='center', rotation='vertical')
# plt.ylabel("log2(time)")
# plt.xlabel("Bot count")
# plt.legend()
plt.show()

plt.errorbar(np.arange(2,6), means, std, fmt='.k', lw=2, label="standard dev")
plt.errorbar(np.arange(2,6), means, [(means - mins), (maxes - means)],fmt='.k', ecolor='gray', lw=1, label="max-min")
plt.title("Map 3")
plt.xlabel("Bot count")
plt.ylabel("Time in s")
plt.legend()
plt.show()