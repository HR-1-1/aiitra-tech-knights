import matplotlib.pyplot as plt
import numpy as np

mins = np.array([7285.040983606557,4871.147540983607,3696.311475409836,2966.065573770492])
maxes = np.array([7526.024590163935,5137.622950819672,3863.27868852459,3086.5573770491806])
means = np.array([7376.9592842367365,4967.645432005465,3753.4619187344524,3013.205984729396])
std = np.array([31.27651223628917,28.087391581434236,22.90948446464094,23.481797602603628])
# create stacked errorbars:
figure, axis = plt.subplots(4,1)
for graph in range(4):
    axis[graph].errorbar(graph+2, means[graph], std[graph], fmt='.k', lw=2, label="standard dev")
    axis[graph].errorbar(graph+2, means[graph], [[(means - mins)[graph]], [(maxes - means)[graph]]],fmt='.k', ecolor='gray', lw=1, label="max-min")
    axis[graph].set_xlim(1,6)
    axis[graph].set_ylim(means[graph]+250,means[graph]-250)
    axis[graph].spines['bottom'].set_visible(False)
    axis[graph].spines['top'].set_visible(False)
    axis[graph].xaxis.set_visible(False)

    d = .015  # how big to make the diagonal lines in axes coordinates
    kwargs = dict(transform=axis[graph].transAxes, color='k', clip_on=False)
    if(graph!=3):
        # arguments to pass to plot, just so we don't keep repeating them
        axis[graph].plot((-d, +d), (-d, +d), **kwargs)        # top-left diagonal
        axis[graph].plot((1 - d, 1 + d), (-d, +d), **kwargs)  # top-right diagonal

    if(graph!=0):
        kwargs.update(transform=axis[graph].transAxes)  # switch to the bottom axes
        axis[graph].plot((-d, +d), (1 - d, 1 + d), **kwargs)  # bottom-left diagonal
        axis[graph].plot((1 - d, 1 + d), (1 - d, 1 + d), **kwargs)  # bottom-right diagonal

axis[0].spines['top'].set_visible(True)
axis[3].spines['bottom'].set_visible(True)
axis[3].xaxis.set_visible(True)
axis[0].legend()
axis[0].set_title("Map 2")
figure.text(0.5, 0.04, 'Bot Count', ha='center', va='center')
figure.text(0.06, 0.5, 'Time in s', ha='center', va='center', rotation='vertical')
# plt.ylabel("log2(time)")
# plt.xlabel("Bot count")
# plt.legend()
plt.show()

plt.errorbar(np.arange(2,6), means, std, fmt='.k', lw=2, label="standard dev")
plt.errorbar(np.arange(2,6), means, [(means - mins), (maxes - means)],fmt='.k', ecolor='gray', lw=1, label="max-min")
plt.title("Map 2")
plt.xlabel("Bot count")
plt.ylabel("Time in s")
plt.legend()
plt.show()