decide the number of random positions you want ( variable name : count ) and the minimum distance between each bot (5,10,15,20)
make the above 2 changes in the -- in_pos_random-euclidiean.py

decide the number of iterations after which DARP decides that solution is not found ( variable name : MaxIter)
make the above change in darpinPoly.py

run in_pos_random-euclidiean.py to generate the in_pos input :
$ python3 in_pos_random-euclidiean.py
This command creates a txt file that saved the in_pos combinations named : in_pos_combinations.txt

then run the simulation__run_command (MAP 1): 
$ cat in_pos_combinations.txt | xargs -I % sh -c 'python3 darpinPoly.py -grid 50 50 -in_pos % -nep -portions 0.2 0.2 0.2 0.2 0.2'