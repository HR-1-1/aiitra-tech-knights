import itertools
import random

input_file = open("data.txt","r")
output_file = open("in_pos_combinations.txt","w")
content = input_file.read()
map_wise = content.split("\n\n")


whole_map = [str(x) for x in range(2500)]
obstacle_list = []
obstacle_list.append([])

for x in range(len(map_wise)):
    obstacle_list.append(map_wise[x].split(" "))

def Diff(li1, li2):
    li_dif = [i for i in li1 if i not in li2]
    return li_dif

def grid_pos(long_pos):
    position = int(long_pos)
    rows = 50
    cols = 50
    [i,j]=[position % cols, position// cols]
    return(i,j)

def Euclidean_dist(x1,y1,x2,y2):
    dist = (((x2-x1)**2) + ((y2-y1)**2))**(0.5)
    return dist


map_number = 1 ## Range from 0 to 3 ##
robot_possible_locations = Diff(whole_map,obstacle_list[map_number])
bot_count = 3
count = 0

while count < 10000:
    count += 1
    p1 = random.choice(robot_possible_locations)
    p2 = random.choice(robot_possible_locations)
    p3 = random.choice(robot_possible_locations)
    [i1,j1] = grid_pos(p1)
    [i2,j2] = grid_pos(p2)
    [i3,j3] = grid_pos(p3)
    mutual_distance_1 = Euclidean_dist(i1,j1,i2,j2)
    mutual_distance_2 = Euclidean_dist(i1,j1,i3,j3)
    mutual_distance_3 = Euclidean_dist(i2,j2,i1,j1)

    min_mutual_distance = min(mutual_distance_1, mutual_distance_2, mutual_distance_3)
    # obstacles = ' '.join(obstacle_list[map_number])
    # command = ""
    # command += ("python3 darpinPoly.py -grid 50 50 -in_pos " + positions + " -nep -portions ")
    # #print("python3 darpinPoly.py -grid 50 50 -in_pos " + positions,end=" -nep -portions ")
    # for bot in range(bot_count):
    #     command += (str(1/bot_count)+" ")
    # command += ("-obs_pos "+obstacles)
    # output_file.write(command+"\n")

    if min_mutual_distance < 10:
        count -=1
        continue
    output_file.write(str(p1)+" "+str(p2)+" "+str(p3)+"\n")
    
# cat commands.txt | xargs -I % sh -c 'python3 darpinPoly.py -grid 50 50 -in_pos % -nep -portions 0.2 0.2 0.2 0.2 0.2 -obs_pos 1250 1251 1252 1253 1254 1255 1256 1257 1258 1259 1260 1261 1262 1263 1264 1265 1266 1267 1268 1269 2029 2079 2129 2179 2229 2279 2329 2379 2429 2479'