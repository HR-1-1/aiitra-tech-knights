decide the number of random positions you want ( variable name : count ) and the minimum distance between each bot (5,10,15,20)
make the above 2 changes in the -- in_pos_random-euclidiean.py

decide the number of iterations after which DARP decides that solution is not found ( variable name : MaxIter)
make the above change in darpinPoly.py

run in_pos_random-euclidiean.py to generate the in_pos input :
$ python3 in_pos_random-euclidiean.py
This command creates a txt file that saved the in_pos combinations named : in_pos_combinations.txt

then run the simulation__run_command (MAP 4): 
$ cat in_pos_combinations.txt | xargs -I % sh -c 'python3 darpinPoly.py -grid 0.33333 0.33333 0.33333 -in_pos % -nep -portions 0.5 0.5 -ob_pos 1250 1251 1252 1253 1254 1255 1256 1257 1258 1259 1260 1261 1262 1263 1264 1265 1266 1267 1268 1269 2029 2079 2129 2179 2229 2279 2329 2379 2429 2479'
