import itertools
import random

input_file = open("data.txt","r")
output_file = open("in_pos_combinations_7bots_map1.txt","w")
content = input_file.read()
map_wise = content.split("\n\n")


whole_map = [str(x) for x in range(2500)]
obstacle_list = []
obstacle_list.append([])

for x in range(len(map_wise)):
    obstacle_list.append(map_wise[x].split(" "))

def Diff(li1, li2):
    li_dif = [i for i in li1 if i not in li2]
    return li_dif

def grid_pos(long_pos):
    position = int(long_pos)
    rows = 50
    cols = 50
    [i,j]=[position % cols, position// cols]
    return(i,j)

def Euclidean_dist(x1,y1,x2,y2):
    dist = (((x2-x1)**2) + ((y2-y1)**2))**(0.5)
    return dist


map_number = 0 ## Range from 0 to 3 ##
robot_possible_locations = Diff(whole_map,obstacle_list[map_number])
bot_count = 7
count = 0

while count < 1000:
    count += 1
    point_position = []
    point_coordinates = []
    not_acceptable = 0
    for point in range(bot_count):
        point_position.append(random.choice(robot_possible_locations))

    for point in point_position:
        point_coordinates.append(grid_pos(point))

    for point_pair in itertools.combinations(point_coordinates, 2):
        mutual_distance = Euclidean_dist(point_pair[0][0],point_pair[0][1],point_pair[1][0],point_pair[1][1])
        if mutual_distance < 15:
            not_acceptable = 1
    
    if not_acceptable:
        count -=1
        continue

    for position in point_position:
        if position == point_position[bot_count-1]:
            output_file.write(str(position))
        else:
            output_file.write(str(position)+" ")

    output_file.write("\n")
    
# cat in_pos_combinations_4bots_map4.txt | xargs -I % sh -c 'python3 darpinPoly.py -grid 50 50 -in_pos % -nep -portions 0.25 0.25 0.25 0.25 -obs_pos 1250 1251 1252 1253 1254 1255 1256 1257 1258 1259 1260 1261 1262 1263 1264 1265 1266 1267 1268 1269 2029 2079 2129 2179 2229 2279 2329 2379 2429 247'